const AboutContainer = () => {
  return (
    <section className="about-container">
      <h2>Sobre</h2>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod, dolores!
        Repellendus eius consequuntur, voluptate deserunt perferendis mollitia
        debitis est autem aperiam necessitatibus beatae assumenda illo rem
        architecto quis dolor quae.
      </p>
      <p>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quos veritatis
        aperiam, odit nihil placeat, dolorum sequi reprehenderit fugiat,
        distinctio provident impedit modi neque sapiente voluptate voluptates.
        Maiores sint at dolores?
      </p>
    </section>
  );
};

export default AboutContainer;
